export default function Footer() {
    return(
        <div className="footer">
            Copyright 2022
        </div>
    );
}