package com.studentportal.studentportalapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentportalapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
