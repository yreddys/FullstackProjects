package com.studentportal.studentportalapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentportalapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentportalapiApplication.class, args);
	}

}
