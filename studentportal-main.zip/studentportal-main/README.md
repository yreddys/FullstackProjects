
# studentportal

<img width="1440" alt="Screenshot 2022-05-24 at 11 50 47" src="https://user-images.githubusercontent.com/64640469/170151756-4c8bd4d3-3cfd-49c5-929b-91a12e0fcb4b.png">
